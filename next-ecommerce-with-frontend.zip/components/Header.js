import Link from 'next/link';
import { useState, useEffect } from 'react';
export default function Header() {
  const [cartCount, setCartCount] = useState(0);
  useEffect(()=>{
    try{
      const c = JSON.parse(localStorage.getItem('cart')||'[]');
      setCartCount(c.reduce((s,i)=>s+i.qty,0));
    }catch(e){}
  },[]);
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/"><a className="text-xl font-bold">MyStore</a></Link>
        <nav className="space-x-4">
          <Link href="/"><a className="hover:text-blue-600">Products</a></Link>
          <Link href="/admin"><a className="hover:text-blue-600">Admin</a></Link>
          <Link href="/cart"><a className="px-3 py-2 bg-blue-600 text-white rounded-md">Cart ({cartCount})</a></Link>
        </nav>
      </div>
    </header>
  );
}
