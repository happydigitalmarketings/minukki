import Link from 'next/link';
export default function ProductCard({product}){
  return (
    <div className="bg-white rounded-lg shadow p-4 flex flex-col">
      <div className="h-48 bg-gray-100 rounded mb-4 flex items-center justify-center">
        {product.images && product.images.length ? <img src={product.images[0]} alt={product.title} className="max-h-full" /> : <span className="text-gray-400">No Image</span>}
      </div>
      <h3 className="font-semibold text-lg">{product.title}</h3>
      <p className="text-sm text-gray-500 flex-1">{product.description?.slice(0,140)}</p>
      <div className="mt-3 flex items-center justify-between">
        <div className="text-lg font-bold">₹{product.price}</div>
        <Link href={`/product/${product.slug}`}><a className="text-sm text-blue-600">View</a></Link>
      </div>
    </div>
  );
}
