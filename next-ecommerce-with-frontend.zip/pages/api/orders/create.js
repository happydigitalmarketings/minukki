// pages/api/orders/create.js
const connectDB = require('../../../lib/db').default;
const Order = require('../../../models/Order').default;
module.exports = async (req, res) => {
  await connectDB();
  if (req.method !== 'POST') return res.status(405).end();
  const { items, shippingAddress, total, paymentMethod } = req.body;
  const order = await Order.create({ items, shippingAddress, total, paymentMethod, status: 'pending' });
  res.status(201).json({ orderId: order._id });
};
