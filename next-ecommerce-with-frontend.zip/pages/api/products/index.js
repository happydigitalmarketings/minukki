// pages/api/products/index.js
const connectDB = require('../../../lib/db').default;
const Product = require('../../../models/Product').default;
const { getUserFromReq } = require('../_utils');
module.exports = async (req, res) => {
  await connectDB();
  if (req.method === 'GET') {
    const { page = 1, limit = 12, q } = req.query;
    const query = q && q.length >= 3 ? { $text: { $search: q } } : {};
    const products = await Product.find(query).skip((page - 1) * limit).limit(Number(limit)).sort({ createdAt: -1 });
    res.json(products);
    return;
  }
  if (req.method === 'POST') {
    const user = await getUserFromReq(req);
    if (!user || user.role !== 'admin') return res.status(401).json({ message: 'Unauthorized' });
    const data = req.body;
    const created = await Product.create(data);
    res.status(201).json(created);
    return;
  }
  res.status(405).end();
};
