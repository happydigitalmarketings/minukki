// pages/api/products/[id].js
const connectDB = require('../../../lib/db').default;
const Product = require('../../../models/Product').default;
const { getUserFromReq } = require('../_utils');
module.exports = async (req, res) => {
  await connectDB();
  const { id } = req.query;
  if (req.method === 'GET') {
    const product = await Product.findById(id);
    if (!product) return res.status(404).end();
    res.json(product);
    return;
  }
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'admin') return res.status(401).json({ message: 'Unauthorized' });
  if (req.method === 'PUT') {
    const updated = await Product.findByIdAndUpdate(id, req.body, { new: true });
    res.json(updated);
    return;
  }
  if (req.method === 'DELETE') {
    await Product.findByIdAndDelete(id);
    res.json({ success: true });
    return;
  }
  res.status(405).end();
};
