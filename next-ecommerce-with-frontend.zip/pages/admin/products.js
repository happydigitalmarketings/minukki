import React, { useEffect, useState } from 'react';
import Router from 'next/router';
export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { fetch('/api/products').then(r => r.json()).then(d => { setProducts(d); setLoading(false); }); }, []);
  return (
    <div style={{ padding: 20 }}>
      <h1>Products</h1>
      <button onClick={() => Router.push('/admin/product-edit')}>Create Product</button>
      {loading ? <p>Loading...</p> : (
        <table border={1} cellPadding={8} style={{ marginTop: 20 }}>
          <thead><tr><th>Title</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead>
          <tbody>
            {products.map(p => (
              <tr key={p._id}><td>{p.title}</td><td>{p.price}</td><td>{p.stock}</td>
                <td>
                  <button onClick={() => Router.push(`/admin/product-edit?id=${p._id}`)}>Edit</button>
                  <button onClick={async () => { if (!confirm('Delete?')) return; await fetch(`/api/products/${p._id}`, { method: 'DELETE' }); setProducts(products.filter(x => x._id !== p._id)); }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
