import React, { useEffect, useState } from 'react';
export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  useEffect(() => { fetch('/api/admin/report?from=&to=').then(r => r.json()).then(d => setOrders(d.orders || [])); }, []);
  return (
    <div style={{ padding: 20 }}>
      <h1>Orders</h1>
      <table border={1} cellPadding={8}><thead><tr><th>ID</th><th>Date</th><th>Total</th><th>Status</th></tr></thead>
      <tbody>
        {orders.map(o => (<tr key={o._id}><td>{o._id}</td><td>{new Date(o.createdAt).toLocaleString()}</td><td>{o.total}</td><td>{o.status}</td></tr>))}
      </tbody></table>
    </div>
  );
}
