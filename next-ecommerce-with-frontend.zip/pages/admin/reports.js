import React, { useState } from 'react';
export default function AdminReports() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [summary, setSummary] = useState(null);
  async function generate() {
    const qs = new URLSearchParams({ from, to });
    const r = await fetch(`/api/admin/report?${qs.toString()}`);
    const j = await r.json();
    setSummary(j);
  }
  function downloadCSV() {
    const qs = new URLSearchParams({ from, to });
    window.location.href = `/api/admin/report/csv?${qs.toString()}`;
  }
  return (
    <div style={{ padding: 20 }}>
      <h1>Sales Reports</h1>
      <div>
        <label>From</label>
        <input type="date" value={from} onChange={e => setFrom(e.target.value)} />
        <label>To</label>
        <input type="date" value={to} onChange={e => setTo(e.target.value)} />
        <button onClick={generate}>Generate</button>
        <button onClick={downloadCSV}>Download CSV</button>
      </div>
      {summary && (<div style={{ marginTop: 20 }}><p>Total Orders: {summary.totalOrders}</p><p>Total Sales: {summary.totalSales}</p></div>)}
    </div>
  );
}
