import React from 'react';
import { verifyToken } from '../../lib/auth';
import connectDB from '../../lib/db';
export default function AdminIndex({ user }) {
  return (
    <div style={{ padding: 20 }}>
      <h1>Admin Dashboard</h1>
      <p>Welcome, {user?.name}</p>
      <ul>
        <li><a href="/admin/products">Products</a></li>
        <li><a href="/admin/blogs">Blog Posts</a></li>
        <li><a href="/admin/orders">Orders</a></li>
        <li><a href="/admin/reports">Sales Reports</a></li>
      </ul>
    </div>
  );
}
export async function getServerSideProps({ req }) {
  const cookies = req.headers.cookie || '';
  const token = cookies.split('token=')[1] ? cookies.split('token=')[1].split(';')[0] : null;
  const user = token ? await verifyToken(token) : null;
  if (!user || user.role !== 'admin') {
    return { redirect: { destination: '/admin/login', permanent: false } };
  }
  await connectDB();
  return { props: { user: { name: user.name, email: user.email } } };
}
