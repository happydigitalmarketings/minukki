import React, { useState } from 'react';
import Router from 'next/router';
export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState(null);
  async function submit(e) {
    e.preventDefault();
    const res = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
    if (res.ok) Router.push('/admin'); else { const j = await res.json(); setErr(j.message || 'Login failed'); }
  }
  return (
    <div style={{ padding: 20 }}>
      <h1>Admin Login</h1>
      <form onSubmit={submit}>
        <div><label>Email</label><input value={email} onChange={e => setEmail(e.target.value)} /></div>
        <div><label>Password</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} /></div>
        <button type="submit">Login</button>
        {err && <p style={{ color: 'red' }}>{err}</p>}
      </form>
    </div>
  );
}
