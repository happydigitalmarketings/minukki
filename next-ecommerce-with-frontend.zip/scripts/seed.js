// scripts/seed.js
(async () => {
  try {
    const mongoose = require('mongoose');
    const connectDB = require('../lib/db').default;
    const Product = require('../models/Product').default;
    const User = require('../models/User').default;
    const bcrypt = require('bcryptjs');
    await connectDB();
    console.log('Connected to DB');
    const products = [
      { title: 'HP 840 G3', slug: 'hp-840-g3', description: 'Refurbished HP 840 G3 — i5, 16GB RAM, 512GB SSD', price: 21500, stock: 5, images: [] },
      { title: 'Dell Latitude 7450', slug: 'dell-latitude-7450', description: 'Business laptop — Dell Latitude 7450', price: 25000, stock: 3 }
    ];
    await Product.deleteMany({});
    await Product.insertMany(products);
    console.log('Seeded products');
    const adminEmail = process.env.SEED_ADMIN_EMAIL || 'admin@example.com';
    const adminPassword = process.env.SEED_ADMIN_PASSWORD || 'password123';
    const existing = await User.findOne({ email: adminEmail });
    if (!existing) {
      const passwordHash = await bcrypt.hash(adminPassword, 10);
      await User.create({ name: 'Admin', email: adminEmail, passwordHash, role: 'admin' });
      console.log('Admin user created:', adminEmail, adminPassword);
    } else {
      console.log('Admin already exists');
    }
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();
