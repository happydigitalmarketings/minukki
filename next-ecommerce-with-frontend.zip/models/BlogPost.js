const mongoose = require('mongoose');
const BlogSchema = new mongoose.Schema({
  title: String,
  slug: { type: String, unique: true },
  content: String,
  excerpt: String,
  publishedAt: Date,
  author: String
});
module.exports.default = mongoose.models.BlogPost || mongoose.model('BlogPost', BlogSchema);
