const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  passwordHash: String,
  role: { type: String, enum: ['admin','customer'], default: 'customer' }
});
module.exports.default = mongoose.models.User || mongoose.model('User', UserSchema);
